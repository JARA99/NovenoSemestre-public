/*
*
*/

#ifndef __QNET6KROOTDATAVIEWERCLA_HH__
#define __QNET6KROOTDATAVIEWERCLA_HH__

#include "CLAcmdln.hh"

class CLAcommandLine;

class qN6kRootDataViewerCLA: public CLAcommandLine{
public:
	qN6kRootDataViewerCLA(int ArgCount, char** ArgVector);
};


#endif // __QNET6KROOTDATAVIEWERCLA_HH__